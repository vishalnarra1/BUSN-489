import Foundation
//Data types

//String
"hi how are you"

//Int
12
34

//Double
2.3456

//Boolean
true
false

var myVar : String = "hi"
myVar = "bye"
print(myVar)

var myInt:Int = 20
myInt = myInt + 1
print(myInt)

var cVar = "hi"
print(cVar)

let myConst:String = "hello"
print(myConst)

var a:Double = 2
var b:Double = 5
var c = pow(a,b)
print(c)
//pow(a,b) with ints did not work

var a1:Double = 2.3
var b1:Double = 5.8
var c1 = floor(a)
var d = ceil(b1)
print(c1)
print(d)

var total:Double = 15
let taxRate:Double = 8.33
var amtOwed:Double = (total + (total*(taxRate/100)))/3.0
print(round(100*amtOwed)/100)

//Functions
//funciton declaration
func myFunc(){
    let a = 10;
    let b = 5;
    
    print (a+b)
}
//function calling
myFunc()

func myFunc2(a:Int){
    //let a = 10;
    let b = 5;
    
    print (a+b)

}
myFunc2(a:10)

func myFunc3(a:Int)->Int{
    //let a = 10;
    let b = 5;
    
    return (a+b)
}
print(myFunc3(a:10))

func myFunc4(_ a:Int, _ b:Int = 0)->Int{
    
    return (a+b)
}
print(myFunc4(10,9))

//argument labels:


func taxFunc(_ tax:Double, _ total:Double, _ people:Int)->Double{
    return ((tax/100)*total+total)/Double(people)
}

print(taxFunc(8.33, 15, 3))

//structures
struct MyStructure{
    //variables and conditions: properties
    var msg:String = "Hi" //stored property
    
    //UI code: View Code
    
    
    //functions: methods
    func myFunction(){
        //code to send chat
        var db:DataBaseManager = DataBaseManager()
        let succ = db.saveData(data:"Hello")
    }
    
    
}
//instance: piece of data that we want to keep track of
var a4:MyStructure = MyStructure()
//the datatype of a structure is the name of the structure itself. You instantiate it by writing the name of the structure followed by ()

a4.msg = "Hello"
a4.myFunction()

//you can create multiple instances of a structure
var b4:MyStructure = MyStructure()
b4.msg = "Bye"
b4.myFunction()

struct DataBaseManager{
    //function to save data and return true if successful
    func saveData(data:String) -> Bool{
        //code to save data
        return true
    }
}
