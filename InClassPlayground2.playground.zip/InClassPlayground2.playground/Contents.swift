import UIKit

let a = false
let b = false
let c = true

if a {
    print("a is true")
}
else if !a || !b && c{
    print("a or b are false")
}
else{
    print("a is false")
}

//8 queens pseudo code
//Make an 8 by 8 array populated with 0s
//enter a 1 in the first position, iterate through the array and check each position for if a queen can be placed, if it can make the number a 1. The program continues until a queen can't eb placed or all 8 are placed. If a queen cant be placed, the program removes the previous queen placed and continues on. If the same 

